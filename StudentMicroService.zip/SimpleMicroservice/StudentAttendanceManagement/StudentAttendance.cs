﻿using System.ComponentModel.DataAnnotations;

namespace StudentAttendanceManagement
{
    public class StudentAttendance
    {
        [Key, Required]
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public float AttendancePercentage { get; set; }
    }
}
