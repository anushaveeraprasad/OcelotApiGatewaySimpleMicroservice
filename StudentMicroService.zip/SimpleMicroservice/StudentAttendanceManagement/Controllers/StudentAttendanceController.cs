﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using Dapper;


namespace StudentAttendanceManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentAttendanceController : ControllerBase
    {
        private readonly IConfiguration _config;
        public StudentAttendanceController(IConfiguration configuration)
        {
            _config = configuration;
        }
        // GET: api/<StudentAttendanceController>
        [HttpGet()]
        public IEnumerable<StudentAttendance> GetAlStudents()
        {
            using var connectionstring = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
            var students = connectionstring.Query<StudentAttendance>("Select * from StudentAttendance");
            return students;

        }

        
    }
}
