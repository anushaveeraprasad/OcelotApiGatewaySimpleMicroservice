﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using StudentAttendanceManagement;

namespace StudentAdmissionManagement
{
    public class StudentAdmission
    {
        
        public int StudentId { get; set; }
        //[ForeignKey("StudentId")]
       // public StudentAttendance StudentAttendance { get; set; }
        public string StudentName { get; set; }
        public DateTime DateOfJoining { get; set; }
        public string StudentClass { get; set; }

    }
}
