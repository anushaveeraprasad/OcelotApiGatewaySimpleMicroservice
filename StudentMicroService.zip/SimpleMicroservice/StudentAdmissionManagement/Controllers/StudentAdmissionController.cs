﻿using Microsoft.AspNetCore.Mvc;
//using StudentAttendanceManagement;
using System.Data.SqlClient;
using Dapper;
using NUnit.Framework;
using System.Diagnostics;
using StudentAttendanceManagement;
//using StudentAttendanceManagement;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace StudentAdmissionManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class StudentAdmissionController : ControllerBase
    {
        private readonly IConfiguration _config;
        public StudentAdmissionController(IConfiguration configuration)
        {
            _config=configuration;
        }
        // GET: api/<StudentAdmissionController>
        [HttpGet()]
        public IEnumerable<StudentAdmission> Get()
        {
            //try
            //{
            //    using var connectionString = new SqlConnection(_config.GetConnectionString("DefaultConnection"));
            //    var allstudents = connectionString.Query<StudentAdmission>("Select * from StudentAdmission");
            //    return allstudents;
            //}

            try
            {
                StudentAdmission objstudent1 = new StudentAdmission()
                {
                    StudentId = 11,
                    StudentName = "Aniruddh",
                    StudentClass = "ix",
                    DateOfJoining = DateTime.Now
                };
                StudentAdmission objstudent2 = new StudentAdmission()
                {
                    StudentId = 10,
                    StudentName = "Bimal",
                    StudentClass = "ix",
                    DateOfJoining = DateTime.Now
                };
                List<StudentAdmission> studentList = new List<StudentAdmission>();
                studentList.Add(objstudent1);
                studentList.Add(objstudent2);
                return studentList;
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); return null; }
            
        }

        
    }
}
